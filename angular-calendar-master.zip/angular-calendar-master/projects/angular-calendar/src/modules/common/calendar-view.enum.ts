export enum CalendarView {
  Month = 'month',
  Week = 'week',
  Day = 'day'
}
