The issue tracker is for bug reports and feature requests only!

To file support issues, please consider becoming a Silver level sponsor on Patreon: https://www.patreon.com/mattlewis92
