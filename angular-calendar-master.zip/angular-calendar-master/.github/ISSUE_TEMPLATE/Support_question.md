---
name: "\U0001F914Support question"
about: Ask a question about the project
title: Become a sponsor on Patreon to ask questions
labels: ''
assignees: ''
---

To ask any questions you'd like about the calendar beyond bug and feature requests, you must become a silver sponsor or higher on Patreon: https://www.patreon.com/mattlewis92
